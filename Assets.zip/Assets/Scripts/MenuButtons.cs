﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuButtons : MonoBehaviour
{
    public Button Button1;
    public Button Button2;
    public Button Button3;
    public Button Button4;
    public Button Button5;


    public void Level1()
    {
        SceneManager.LoadScene("Level1");
    }

    public void Level2()
    {
        SceneManager.LoadScene("Level2");
    }

    public void Level3()
    {
        SceneManager.LoadScene("Level3");
    }

    public void Level4()
    {
        SceneManager.LoadScene("Level4");
    }

    public void Level5()
    {
        SceneManager.LoadScene("Level5");
    }

    public void ExitGame()
    {
        Application.Quit();
    }

    private bool Unlock(int x)
    {
        if (PlayerPrefs.GetInt("levelsBeat") >= x)
        {
            return true;
        } else
        {
            return false;
        }
    }

    private void Start()
    {
        Button1.interactable = Unlock(1);
        Button2.interactable = Unlock(2);
        Button3.interactable = Unlock(3);
        Button4.interactable = Unlock(4);
        Button5.interactable = Unlock(5);
    }
}
