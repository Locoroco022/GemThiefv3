﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    SaveData saveData = new SaveData();

    public float speed = 0;
    public TextMeshProUGUI objectiveText;
    public TextMeshProUGUI clickText;
    public TextMeshProUGUI totalText;
    public GameObject winTextObject;
    public GameObject loseTextObject;
    public string nextLevel;
    public string currentLevel;
    public int levelNumb;

    private Rigidbody rb;
    private bool stolen;
    static public int winOrLose; // 0 = neutral | 1 = lost | 2 = won |
    private float movementX;
    private float movementY;

    // Start is called before the first frame update
    void Start()
    {
        //saveData = SaveSystem.instance.LoadGame(); //loads the players total score and displays it
    
        rb = GetComponent<Rigidbody>();
        stolen = false;
        winOrLose = 0; //winner will help make sure the player can't lose after winning

        SetObjectiveText();
        winTextObject.SetActive(false);
        loseTextObject.SetActive(false);
        LoadFile();
        totalText.text = "Total Gems: " + saveData.gemScore;
    }

    void LoadFile ()
    {
        saveData = SaveSystem.instance.LoadGame();
    }

    void OnMove(InputValue movementValue)
    {
        Vector2 movementVector = movementValue.Get<Vector2>();

        movementX = movementVector.x;
        movementY = movementVector.y;
    }

    void OnClick()
    {
        if (winOrLose == 2)
        {
            PlayerPrefs.SetInt("levelsBeat", levelNumb);
            PlayerPrefs.Save();
            SceneManager.LoadScene(nextLevel);
        }
        else if (winOrLose == 1)
        {
            SceneManager.LoadScene(currentLevel);
        }
    }

    void OnEscape()
    {
            SceneManager.LoadScene("MainMenu");       
    }

    void SetObjectiveText()
    {
        if(stolen == true)
        {
            objectiveText.text = "Gem: Stolen";
        }
        else
        {
            objectiveText.text = "Gem: Not Found";
        }
    }

    void FixedUpdate()
    {
        Vector3 movement = new Vector3(movementX, 0.0f, movementY);

        rb.AddForce(movement * speed);
    }

    private void OnTriggerEnter(Collider other)
    {

        //Code for when the player picks up the gem
        if(other.gameObject.CompareTag("Gem"))
        {
            other.gameObject.SetActive(false);
            stolen = true;
            SetObjectiveText();
        }


        //Code for when the player touches the base and wins
        if (other.gameObject.CompareTag("Base"))
        {
            if (stolen == true)
            {
                saveData = SaveSystem.instance.LoadGame();
                saveData.AddGem(1); // this chunk adds to the total gems, saves the data, then displays it.
                SaveSystem.instance.SaveGame(saveData);
                totalText.text = "Total Gems: " + saveData.gemScore;

                winOrLose = 2;
                winTextObject.SetActive(true);
                clickText.text = "Click to Continue";
                speed = 0;
                this.transform.GetComponent<Rigidbody>().isKinematic = true;
                stolen = false; // this is to make sure this if statement doesn't trigger again
            }
        }

        //Code for when the player is touched and loses
        if (other.gameObject.CompareTag("Guard"))
        {
            if (winOrLose == 0)
            {
                winOrLose = 1;
                loseTextObject.SetActive(true);
                clickText.text = "Click to Restart";
                speed = 0;
                this.transform.GetComponent<Rigidbody>().isKinematic = true; //stops player when caught
            }
        }
    }
}
