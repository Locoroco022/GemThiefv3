﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData
{
    public int gemScore = 0;

    public void AddGem(int points)
    {
        gemScore = gemScore + points;
    }

    public void ResetData()
    {
        gemScore = 0;
    }
}


