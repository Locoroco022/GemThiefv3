﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;

public class NPCController : MonoBehaviour
{
    public float patrolTime = 15;  
    public float aggroRange = 10;
    public Transform[] waypoints;

    int index;
    float speed, agentSpeed;
    Transform player;

    NavMeshAgent agent;

    RaycastHit hit;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();

        if (agent != null) 
        {
            agentSpeed = agent.speed;
        }

        player = GameObject.FindGameObjectWithTag("Player").transform;
        index = Random.Range(0, waypoints.Length);

        InvokeRepeating("Tick", 0, 0.5f);

        if (waypoints.Length > 0)
        {
            InvokeRepeating("Patrol", 0, patrolTime);
        }
    }

    void Patrol()
    {
        index = index == waypoints.Length - 1 ? 0 : index + 1;
    }

    private void Update()
    {
        //this code is to stop the guards when the game is over or won.
        if (PlayerController.winOrLose != 0)
        {
            agent.speed = 0;
        }
    }


    void Tick()
    {
        agent.destination = waypoints[index].position;
        agent.speed = agentSpeed / 2;

        // This code chunk checks if the player is both in range and in sight before pursuing   
            if (Vector3.Distance(transform.position, player.position) < aggroRange)
            {
                if (Physics.Raycast(transform.position, (player.position - transform.position), out hit, aggroRange))
                {
                    if (hit.transform == player)
                    {
                        agent.destination = player.position;
                        agent.speed = agentSpeed;
                    }
                }
            }
        
    }
}
