﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSpawner : MonoBehaviour
{

    public GameObject bullet;
    public float bulletTime = 1;
    float RPS;


    // Start is called before the first frame update
    void Start()
    {
        RPS = bulletTime;
        bigShooty();
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerController.winOrLose == 0) //stops shooting with the game is over or won
        {         
            if (RPS <= 0.0f)       
            {            
                bigShooty();            
                RPS = bulletTime;       
            }       
            else        
            {            
                RPS -= Time.deltaTime;        
            }   
        }
    }

    void bigShooty()
    {
        Instantiate(bullet, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y, gameObject.transform.position.z), gameObject.transform.rotation);
    }
}
